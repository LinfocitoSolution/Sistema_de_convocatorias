
<!doctype html>
<html>
 <head>
    <title>Convocatoria - <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/convo/convoca.css')); ?>" rel="stylesheet">            
    
   
   
 </head>  
   <body>
        <div class=info>
         <?php echo $__env->yieldContent("informacion"); ?>
        </div>    
        
          <?php echo $__env->make("admin.layouts.script", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </body>
        
</html> 