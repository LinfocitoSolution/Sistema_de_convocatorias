@extends("admin.layouts.plantilladmin")

@section('title')
    convocatoria
@endsection

@section("content")
 <!-- Content Wrapper. Contains contiene paginas -->
 <div class="content-wrapper">
    
    <h4>Soy el index de convocatoria</h4>
    
  </div>
  <!-- /.content-wrapper -->

@endsection

