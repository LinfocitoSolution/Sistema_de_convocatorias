<nav class="navbar navbar-expand-lg navbar-light bg-info sticky-top">
				<a class="navbar-brand  text-white" href="<?php echo e(url('index')); ?>" tabindex="-1" >Inicio</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
</nav>