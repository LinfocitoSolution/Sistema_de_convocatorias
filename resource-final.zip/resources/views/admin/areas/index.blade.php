@extends("admin.layouts.plantilladmin")

@section('title')
    area
@endsection

@section("content")
 <!-- Content Wrapper. Contains contiene paginas -->
 <div class="content-wrapper">
    
    <h4>esto es AREA</h4>
    
  </div>
  <!-- /.content-wrapper -->

@endsection