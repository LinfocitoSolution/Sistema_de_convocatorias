<?php $__env->startSection("htmlheader_title"); ?>
  LOGIN
<?php $__env->stopSection(); ?>
<?php $__env->startSection("infoGeneral"); ?>

		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
	
		<div classs=contenido-login>
			<div class="container">
				<div class="d-flex justify-content-center h-100">
					<div class="card">
						<div class="card-header">
							<h3>Login Usuario</h3>
						</div>
						<!--cuerpo del login-->				
						<div class="card-body">
							<form class= "form group" method="POST" action="<?php echo e(url('login')); ?>">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

								<div class="input-group form-group">
									<div class="input-group-prepend">
										<span class="input-group-text"><i class="fas fa-user"></i></span>
									</div>
								       <input type="text" class="form-control" placeholder="Nombre de Usuario o email" name="login" id="login" value="<?php echo e(old('username') ?: old('email')); ?>">
								</div>
								
								<div class="input-group form-group">
									<div class="input-group-prepend">
										<span class="input-group-text"><i class="fas fa-key"></i></span>
									</div>
									<input type="password" class="form-control" placeholder="Contraseña" name="password" id="password">
								</div>
								<small id="passwordHelpBlock" class="form-text text-muted"> Tu contraseña debe tener 8-20 caracteres, contener letras y numeros , <br>no debe contener espacios, caracteres especiales, o emoji. </small>
								
								<div class="form-group" >
									<button class="btn btn-outline-primary mr-sm-2" type="submit">INGRESAR</button>
								</div>
							</form>
						
                           <!--footer de login--> 
						   <div class="card-footer">
							   <div class="d-flex justify-content-center links">
								   No tienes cuenta?<a href="<?php echo e(url('registro_postulante')); ?> ">REGISTRATE</a>
							   </div>
							   <div class="d-flex justify-content-center">
								<a href="#">Olviste tu contraseña?</a>
							   </div>
						   </div>
							<!--fin de footer-->
						</div>
						<!--fin cuerpo login-->
					</div>
				</div>
			</div>
		</div>
		
<?php $__env->stopSection(); ?>		
	
<?php echo $__env->make("auth.plantillaLogForm", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>