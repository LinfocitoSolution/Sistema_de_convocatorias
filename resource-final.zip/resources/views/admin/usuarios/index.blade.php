@extends("admin.layouts.plantilladmin")

@section('title')
    Usuarios
@endsection

@section("content")
 <!-- Content Wrapper. Contains contiene paginas -->
 <div class="content-wrapper">
    
    <h4>lista de Usuarios</h4>
    
  </div>
  <!-- /.content-wrapper -->

@endsection