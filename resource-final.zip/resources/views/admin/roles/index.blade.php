@extends("admin.layouts.plantilladmin")

@section('title')
    Roles
@endsection

@section("content")
 <!-- Content Wrapper. Contains contiene paginas -->
 <div class="content-wrapper">
    
    <h4>estos son Roles</h4>
    
  </div>
  <!-- /.content-wrapper -->

@endsection