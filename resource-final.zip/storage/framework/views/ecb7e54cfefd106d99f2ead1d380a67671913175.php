<!doctype html>
<html>

<head>

<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title> <?php echo $__env->yieldContent("title"); ?></title>

<!-- Font Awesome Icons -->
<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<!--Styles-->
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/main.css')); ?>" rel="stylesheet" type="text/css" />

</head>

<body>
  
   
     <?php echo $__env->make("layouts.partials.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <div class="login">
     <?php echo $__env->yieldContent("infoGeneral"); ?>
     </div>
     <?php echo $__env->make("layouts.partials.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     
</body>
</html>