<!doctype html>
<html>

<head>

<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title> plantilla </title>

<!-- Font Awesome Icons -->
<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<!--Styles-->
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/main.css')); ?>" rel="stylesheet" type="text/css" />
<?php echo $__env->yieldContent('stilo'); ?>
</head>

<body>
<div id="contenedor">
   <header>
     <?php echo $__env->yieldContent("cabecera"); ?>
     
   </header>

   <section>
    <div class="login">
     <?php echo $__env->yieldContent("infoGeneral"); ?>
     </div>
   </section>
 
   
</div>
<script>
			window.Laravel = <?php echo json_encode([
				'csrfToken' => csrf_token(),
			]); ?>
		</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

</body>
</html>